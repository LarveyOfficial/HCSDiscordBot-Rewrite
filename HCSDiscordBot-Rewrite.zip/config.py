import pymongo
import logging

TOKEN = "NTY1MzUzMzU1Njc4MDU2NDQ4.XNR9gQ.7pf6NN2d83_WgBNCcQyXh7d7Cc8"

ownerID = [245653078794174465]

MAINCOLOR = 0x003366

ERRORCOLOR = 0xff0000

CLUSTER = pymongo.MongoClient("mongodb+srv://hcsdiscord:hcsdiscord@hcsdiscordbot-d62f7.mongodb.net/test?retryWrites=true")

USERS = CLUSTER['HCS']['users']

role_list = ['band', 'nintendoswitch', 'minecraft', 'bedwars', 'communist', 'art', 'languages', 'gamer', 'ping']
mailfromserver = "smtp.gmail.com:587"
mailfromAddress = "hcsdiscordbot@gmail.com"
mailfrompassword = "Qn5ubGC4MXsXnxf"
guild_id = 543059123730644992
invite_url = 'https://discord.gg/rnh2epE'